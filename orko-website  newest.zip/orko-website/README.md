# ORKO — website

Static site, no build step. Deploy the folder as-is (Vercel: drag the folder in, or run `vercel` inside it; framework preset "Other").

- `index.html` — the whole page (HTML, CSS, JS)
- `lib/three.min.js` — 3D library (three.js r128), served locally
- `favicon.svg` — tab icon

## Analytics
Vercel Web Analytics is already in `index.html` (the `/_vercel/insights/script.js` tag — the plain-HTML version of `@vercel/analytics`, no npm needed).
Turn it on in the Vercel dashboard: project → Analytics → Enable, then redeploy. Data appears after the first visits. It uses no cookies.

## Forms
In `index.html` search for `FORM_ENDPOINT`.
- Empty (now): both forms open the visitor's e-mail app with the message pre-filled to ahoj@orko.sk.
- Recommended: create a free form at formspree.io, copy its URL (https://formspree.io/f/xxxxxxx) into `FORM_ENDPOINT` — messages then arrive in your inbox directly, no e-mail app needed.
Change `MAIL_TO` if the real address differs.

## Still to fill in (search the file for `[`)
- Founder photos, names, roles, bios and links (`#zakladatelia`)
- Real e-mail and Instagram/TikTok links
- Legal pages (GDPR, cookies, terms, accessibility…) — footer links point to `#top`
- Operator details (Prevádzkovateľ, Sídlo, IČO/DIČ) — removed for now; add back before going live if required
